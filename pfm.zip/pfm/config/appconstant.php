<?php
return array(
    // gender
    'male' => 'male',
    'female' => 'female',

    // Status
    'not_found' => 1,
    'status_inactive' => 0,

    // API Status
    'status_fail' => 'fail',
    'status_ok' => 'ok',

    // Type
    'income' => 1,
    'expense' => 0,

    // API status codes
    'ok' => 200,
    'created' => 201,
    'bad_request' => 400,
    'unauthorized' => 401,
    'forbidden' => 403,
    'not_found' => 404,
    'method_not_allowed' => 405,
    'unprocessable_request' => 422,
    'internal_server_error' => 500,
    'token_invalid' => 503,

    'appname' => 'PFM',
    'api_auth_guard' => 'api',

    // Set Forgot password url valid
    'is_forgot_password_limit' => 60,

    'age'=> array(
        '0-10',
        '11-20',
        '21-30',
        '31-40',
        '41-50',
        '51-60',
        '61-70',
        '71-80',
        '81-90',
        '91-100'
    ),
    'public' => 'public',
    'profileimage' => 'profileimage',
);
