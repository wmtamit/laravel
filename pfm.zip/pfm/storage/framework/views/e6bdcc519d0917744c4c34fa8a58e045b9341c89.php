<?php $__env->startComponent('mail::message'); ?>
Hello <?php echo e($user['fullname']); ?>


The body of your message.

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
    Click here
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('appconstant.appname')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /opt/lampp/htdocs/pfm/resources/views/emails/user/forgotpassword.blade.php ENDPATH**/ ?>