<?php $__env->startComponent('mail::message'); ?>
Hello <?php echo e($user['fullname']); ?>


Thank you for registration.




Thanks,<br>
<?php echo e(config('appconstant.appname')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /opt/lampp/htdocs/pfm/resources/views/emails/user/signup.blade.php ENDPATH**/ ?>