<?php
return array(
    'jwt_absent' => 'Token not provided.',
    'jwt_not_got' => 'Unable to get token.',
    'jwt_invalid' => 'Invalid token.',
    'jwt_expire' => 'Token expired.',
    'logout_success' => 'Logout successfully.'
);
