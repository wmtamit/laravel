<?php
return array(
    'server_error' => 'Temporary server error. Try Again.',

    // Registration
    'register_success' => 'Signup successfully. I have sent activation email at your email.',

    // login
    'invalid_email_password' => 'These credentials do not match our records.',
    'login_success' => 'Logged in successfully.',

    // Forgot password
    'forgot_password_mail_success' => 'Forgot password mail sent successfully.',
    'emailNotFound' => 'Email id not available in our record.',

    // Reset Password Successfully.
    'reset_password_success' => 'Reset Password Successfully',

    // Forgot Password
    'signout_password_success' => 'Signout Successfully.',
    'expireUrl' => 'This URL is no longer valid.',

    // SignUp
    'confirmPassword' => 'The confirm password field is required.',

    //get User
    'list_success' => 'list successfully.',

    // Profile
    'userNotFound' => 'User not available in our record.',
    'invalidAge' => 'Invalid age selected.',
    'invalidGender' => 'Invalid gender selected.',
    'profileUpdate' => 'Profile update successfully.',

    // Password
    'oldPasswordFailed' => 'Old Password you entered does not match our records.',
    'passwordUpdate' => 'password update successfully.',

    // category
    'categoryType' => 'Type is valid 0 and 1',
    'categoryExpenseType' => 'Expense type is valid 0 and 1',
    'category_create_success'=> "Category create successfully.",
    'sub_category_create_success'=> "Sub Category create successfully.",
    'categoryNotFound' => 'Category not available in our record.',
    'categoryUpdateSuccess'=> "Category update successfully.",
    'alredyChiledCategoryAssign'=> "Already assign the sub category.",
);