<?php
return array(
    'signup' => 'New Registration at PFM.',
    'forgot_password' => 'Forgot password.',
);