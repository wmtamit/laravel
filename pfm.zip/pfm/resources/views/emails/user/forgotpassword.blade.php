@component('mail::message')
Hello {{ $user['fullname'] }}

The body of your message.

@component('mail::button', ['url' => $url])
    Click here
@endcomponent

Thanks,<br>
{{ config('appconstant.appname') }}
@endcomponent
