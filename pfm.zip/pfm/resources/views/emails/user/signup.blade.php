@component('mail::message')
Hello {{ $user['fullname'] }}

Thank you for registration.
{{--@component('mail::button', ['url' => ''])--}}
{{--Click Here--}}
{{--@endcomponent--}}

Thanks,<br>
{{ config('appconstant.appname') }}
@endcomponent
