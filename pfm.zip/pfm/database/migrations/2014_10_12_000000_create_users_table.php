<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->uuid('uuid')->unique();
            $table->string('full_name');
            $table->string('email')->unique();
            $table->string('forgot_password_code')->nullable();
            $table->string('password');
            $table->enum('gender',[config('appconstant.male'),config('appconstant.female')])->nullable();
            $table->string('age',45)->nullable();
            $table->string('profile_pic',255)->nullable();
            $table->tinyInteger('status')->default(config('appconstant.status_active'));
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
