<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

// Prefix & Name Space Define
Route::group(['prefix' => 'v1', 'namespace' => 'Api\V1'], function () {


    // Normal User Start
    Route::namespace('User')->group(function () {

        Route::prefix('user')->group(function () {

            Route::post('signup', 'AuthController@signUp');
            Route::post('signin', 'AuthController@signIn');
            Route::post('forgotpassword', 'AuthController@forgotPassword');
            Route::post('resetpassword', 'AuthController@resetPassword');

            // MiddleWare JWT Token
            Route::middleware('verifyJwtToken')->group(function () {
                Route::post('logout', 'AuthController@signOut'); // Logout Token
                Route::get('profile', 'UserController@profile'); // get All User
                Route::post('profile', 'UserController@updateProfile'); // Update Profile
                Route::post('changepassword', 'UserController@changePassword'); // Change Password
            });

        });
        Route::get('forgot-set-password', 'AuthController@forgotSetPassword')->name('forgot_set_password');

    });

    // Category Route Start
    Route::namespace('Category')->middleware('verifyJwtToken')->group(function () {
        Route::resource('category', 'CategoryController'); // Update Profile
    });


});