<?php

namespace App\Traits;

use Ramsey\Uuid\Uuid;

/**
 * Trait GetUuid
 * @package App\Traits
 */
trait GetUuid
{
    /**
     * @return string
     * @throws \Exception
     */
    public function uuid()
    {
        $uuid4 = Uuid::uuid4();
        return $uuid4->toString();
    }
}