<?php

namespace App\Traits;

trait ApiResponse
{
    protected $meta;
    protected $data;
    protected $paginate;
    protected $response;

    /**
     * @param $key
     * @param $value
     */
    protected function setMeta($key, $value)
    {
        $this->meta[$key] = $value;
    }

    /**
     * @param $key
     * @param $value
     */
    protected function setData($key, $value)
    {
        $this->data[$key] = $value;
        //Log::info($this->data);
    }

    /**
     * @param $value
     */
    protected function setPaginate($value)
    {
        $this->paginate = $value;
        //Log::info($this->data);
    }

    /**
     * @return mixed
     */
    protected function setResponse()
    {
        $this->response['meta'] = $this->meta;
        if ($this->data !== null) {
            $this->response['data'] = $this->data;
        }
        if ($this->paginate !== null) {
            $this->response['pagination'] = $this->paginate;
        }
        $this->meta = array();
        $this->data = array();
        $this->paginate = array();
        return $this->response;
    }

    /**
     * @param string $message
     * @return mixed
     */
    protected function setQueryExceptionResponse($message = '')
    {
        if ($message === '')
            $message = __('messages.server_error');

        $this->meta = array();
        $this->data = array();
        $this->paginate = array();

        $this->meta['status'] = config('appconstant.status_fail');
        $this->meta['message'] = $message;

        $this->response['meta'] = $this->meta;

        $this->meta = array();
        $this->data = array();
        $this->paginate = array();

        return $this->response;
    }
}