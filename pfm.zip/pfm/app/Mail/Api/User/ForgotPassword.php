<?php

namespace App\Mail\Api\User;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\URL;

class ForgotPassword extends Mailable
{
    use Queueable, SerializesModels;

    protected $data;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(array $data)
    {
        $this->data = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $url = URL::temporarySignedRoute(
            'forgot_set_password',
            now()->addMinutes(config('appconstant.is_forgot_password_limit')), array(
                'user' => $this->data['email'],
                'token' => $this->data['forgot_password_code']
            )
        );
        return $this->markdown('emails.user.forgotpassword')
            ->with(array(
                'url' => $url,
                'user' => $this->data
            ))->subject(
                __('emailsubject.forgot_password')
            );
    }
}
