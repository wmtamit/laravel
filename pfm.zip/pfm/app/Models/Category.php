<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    /**
     * @var string
     */
    protected $table = "categories";

    /**
     * @var array
     */
    protected $fillable = array(
        'uuid',
        'user_id',
        'parent_id',
        'type',
        'expense_type',
        'name',
        'status'
    );

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function subCategory(){
        return $this->hasMany(Category::class,'parent_id','id');
    }
}
