<?php

namespace App\Http\Requests\Api\V1\Category;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use App\Traits\ApiResponse;
use App\Rules\AntiXssFinder;
use App\Rules\AlphaSpace;

class CategoryStore extends FormRequest
{
    use ApiResponse;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        // Parent category
        if (request()->has('parent_id') && request('parent_id') != null) {

            $validationArr = array(
                'name' => ['required', 'min:3', 'max:128', 'unique:categories', new AlphaSpace, new AntiXssFinder],
                'type' => ['required', 'integer', 'between:0,0'],
                'expense_type' => ['required', 'integer', 'between:0,1'],
                'parent_id' => ['required', new AntiXssFinder]
            );

        } else {
            $validationArr = array(
                'name' => ['required', 'min:3', 'max:128', 'unique:categories', new AlphaSpace, new AntiXssFinder],
                'type' => ['required', 'integer', 'between:0,1'],
            );
            if (request('type') == config('appconstant.expense')) {
                $validationArr['expense_type'] = ['required', 'integer', 'between:0,1'];
            }
        }

        return $validationArr;
    }

    /**
     * @return array
     */
    public function messages()
    {
        if (request()->has('parent_id') && request('parent_id') != null) {
            return array(
                'type.between' => __('Type is valid 0'),
                'expense_type.between' => __('messages.categoryExpenseType'),
                'parent_id.required' => __('Parent category is required')
            );
        } else {
            return array(
                'type.between' => __('messages.categoryType'),
                'expense_type.between' => __('messages.categoryExpenseType')
            );
        }
    }

    /**
     * @param Validator $validator
     */
    protected function failedValidation(Validator $validator)
    {
        $this->setMeta("status", config('appconstant.status_fail'));
        $this->setMeta("message", $validator->messages()->first());
        throw new HttpResponseException(
            response()->json(
                $this->setResponse(),
                config('appconstant.unprocessable_request')
            )
        );
    }
}
