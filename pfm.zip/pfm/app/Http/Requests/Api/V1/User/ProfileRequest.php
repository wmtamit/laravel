<?php

namespace App\Http\Requests\Api\V1\User;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use App\Traits\ApiResponse;
use App\Rules\AntiXssFinder;
use App\Rules\AlphaSpace;

class ProfileRequest extends FormRequest
{
    use ApiResponse;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        if (request()->file('profile_pic') && request()->file('profile_pic') != null) {
            return [
                'profile_pic' => 'required|image|mimes:jpg,png,jpeg|max:2000'
            ];
        } else {
            return array(
                'full_name' => ['required', 'min:3', 'max:30', new AlphaSpace, new AntiXssFinder],
                'age' => ['required', new AntiXssFinder],
                'gender' => ['required', new AntiXssFinder],
            );
        }
    }

    /**
     * @param Validator $validator
     */
    protected function failedValidation(Validator $validator)
    {
        $this->setMeta("status", config('appconstant.status_fail'));
        $this->setMeta("message", $validator->messages()->first());
        throw new HttpResponseException(
            response()->json(
                $this->setResponse(),
                config('appconstant.unprocessable_request')
            )
        );
    }
}
