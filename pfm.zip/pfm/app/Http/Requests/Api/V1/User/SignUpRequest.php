<?php

namespace App\Http\Requests\Api\V1\User;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
use App\Traits\ApiResponse;
use App\Rules\AntiXssFinder;
use App\Rules\AlphaSpace;

/**
 * Class SignUpRequest
 * @package App\Http\Requests\Api\V1\User
 */
class SignUpRequest extends FormRequest
{
    use ApiResponse;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return array(
            'full_name' => ['required', 'min:3', 'max:30', new AlphaSpace, new AntiXssFinder],
            'email' => ['required', 'email', 'unique:users', 'max:150', new AntiXssFinder],
            'password' => ['required', 'min:8', 'confirmed','max:30']
        );
    }

    /**
     * @return array
     */
    public function messages()
    {
        return array(
            'confirm_password.required' => __('messages.confirmPassword')
        );
    }

    /**
     * @param Validator $validator
     */
    protected function failedValidation(Validator $validator)
    {
        $this->setMeta("status", config('appconstant.status_fail'));
        $this->setMeta("message", $validator->messages()->first());
        throw new HttpResponseException(
            response()->json(
                $this->setResponse(),
                config('appconstant.unprocessable_request')
            )
        );
    }
}
