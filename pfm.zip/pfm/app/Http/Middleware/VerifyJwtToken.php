<?php

namespace App\Http\Middleware;

use Closure;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Traits\ApiResponse;

class VerifyJwtToken
{
    use ApiResponse;
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $token = JWTAuth::getToken();
        if(!$token){
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('jwt.jwt_absent'));
            return response()->json($this->setResponse(), config('appconstant.bad_request'));
        }
        try {
            $user = auth()->guard(config('appconstant.api_auth_guard'))->user();
            if (!$user) {
                $this->setMeta('status', config('appconstant.status_fail'));
                $this->setMeta('message', __('jwt.jwt_invalid'));
                return response()->json($this->setResponse(), config('appconstant.token_invalid'));
            }
        } catch (\TokenExpiredException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('jwt.jwt_expire'));
            return response()->json($this->setResponse(), config('appconstant.token_invalid'));
        } catch (\TokenInvalidException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('jwt.jwt_invalid'));
            return response()->json($this->setResponse(), config('appconstant.token_invalid'));
        } catch (\JWTException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('jwt.jwt_invalid'));
            return response()->json($this->setResponse(), config('appconstant.token_invalid'));
        }
        $request->merge(['user' => $user]);
        return $next($request);
    }
}
