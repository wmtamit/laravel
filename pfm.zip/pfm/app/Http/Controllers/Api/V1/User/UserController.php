<?php

namespace App\Http\Controllers\Api\V1\User;

use Carbon\Carbon;
use Illuminate\Database\QueryException;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Traits\ApiResponse;
use App\Http\Requests\Api\V1\User\ProfileRequest;
use App\Http\Requests\Api\V1\User\ChangePassword;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

/**
 * Class UserController
 * @package App\Http\Controllers\Api\V1\User
 */
class UserController extends Controller
{
    use ApiResponse;

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function profile(Request $request)
    {
        $user = $request->user;
        if ($user == null) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.emailNotFound'));
            return response()->json($this->setResponse(), config('appconstant.not_found'));
        }

        // Success Response Set
        $this->setMeta('status', config('appconstant.status_ok'));
        $this->setMeta('message', __('messages.list_success'));
        $this->setData('user', $user);
        return response()->json($this->setResponse(), config('appconstant.ok'));
    }


    /**
     * @param ProfileRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateProfile(ProfileRequest $request)
    {
        try{

            $user = $request->user;
            // User = null this error show
            if ($user == null) {
                $this->setMeta('status', config('appconstant.status_fail'));
                $this->setMeta('message', __('messages.userNotFound'));
                return response()->json($this->setResponse(), config('appconstant.not_found'));
            }

            $profile_pic = $request->file('profile_pic');
            if ($profile_pic != null) {
                // Profile Image Upload Start
                $filename = mt_rand(111111, 999999) . '_' . $user->uuid;
                $profilePicPath = $profile_pic->storeAs(
                    config('appconstant.profileimage'), $filename . "." . $profile_pic->getClientOriginalExtension(), config('appconstant.public')
                );
                if ($profilePicPath != null) {
                    $updateArr['profile_pic'] = $profilePicPath;
                }

                if ($user->profile_pic != "") {
                    $path_parts = pathinfo($user->profile_pic);
                    Storage::delete('/' . config('appconstant.public') . '/' . config('appconstant.profileimage') . '/' . $path_parts['basename']);
                }
                // Profile Image Upload End
            } else {
                // age check
                if (!in_array($request->age, config('appconstant.age'))) {
                    $this->setMeta('status', config('appconstant.status_fail'));
                    $this->setMeta('message', __('messages.invalidAge'));
                    return response()->json($this->setResponse(), config('appconstant.not_found'));
                }

                if (!in_array($request->gender, [config('appconstant.male'), config('appconstant.female')])) {
                    $this->setMeta('status', config('appconstant.status_fail'));
                    $this->setMeta('message', __('messages.invalidGender'));
                    return response()->json($this->setResponse(), config('appconstant.not_found'));
                }

                // Update User info Start
                $updateArr = array(
                    'age' => $request->age,
                    'gender' => $request->gender,
                    'full_name' => $request->full_name,
                );
                // Update User info Start
            }
            // Update Password
            $updateArr['updated_at'] = Carbon::now();
            $user->update($updateArr);

            // Success response
            $this->setMeta('status', config('appconstant.status_ok'));
            $this->setMeta('message', __('messages.profileUpdate'));
            $this->setData('user', $user);
            return response()->json($this->setResponse(), config('appconstant.ok'));

        }catch (QueryException $e){// Server Error
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.server_error'));
            return response()->json($this->setResponse(), config('appconstant.internal_server_error'));
        }
    }

    /**
     * @param ChangePassword $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function changePassword(ChangePassword $request)
    {
        try {

            $user = $request->user;
            if (!Hash::check($request->old_password, $user->password)) {
                $this->setMeta('status', config('appconstant.status_fail'));
                $this->setMeta('message', __('messages.oldPasswordFailed'));
                return response()->json($this->setResponse(), config('appconstant.unauthorized'));
            }

            // update Password Start
            $user->update([
                'password' => Hash::make($request->password),
                'updated_at' => Carbon::now()
            ]);

            // Success response
            $this->setMeta('status', config('appconstant.status_ok'));
            $this->setMeta('message', __('messages.passwordUpdate'));
            return response()->json($this->setResponse(), config('appconstant.ok'));

        } catch (QueryException $e) {// Server Error
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.server_error'));
            return response()->json($this->setResponse(), config('appconstant.internal_server_error'));
        }
    }
}
