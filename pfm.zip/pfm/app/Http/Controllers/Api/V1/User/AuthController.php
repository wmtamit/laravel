<?php

namespace App\Http\Controllers\Api\V1\User;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Database\QueryException;
use App\Models\User;
use Ramsey\Uuid\Uuid;
use Illuminate\Support\Facades\Hash;
use App\Traits\ApiResponse;
use App\Http\Requests\Api\V1\User\SignUpRequest;
use App\Http\Requests\Api\V1\User\SignInRequest;
use App\Http\Requests\Api\V1\User\ForgotRequest;
use App\Http\Requests\Api\V1\User\ResetPassword;
use App\Jobs\User\SignUp as JobSignUp;
use App\Jobs\User\ForgotPassword as JobForgotPassword;
use App\Utils\GetTokens;
use App\Traits\GetUuid;

/**
 * Class AuthController
 * @package App\Http\Controllers\Api\V1\User
 */
class AuthController extends Controller
{
    use ApiResponse;
    use GetUuid;

    /**
     * @param SignUpRequest $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Exception
     */
    public function signUp(SignUpRequest $request)
    {
        // Check Try & Catch
        try {
            // User Create Start
            $user = User::create(array(
                'uuid' => $this->uuid(),
                'full_name' => $request->full_name,
                'email' => $request->email,
                'password' => Hash::make($request->password),
                'status' => config('appconstant.status_active'),
            ));
            // User Create End

            // Jobs Start
            $mailArr = array(
                'fullname' => $user->full_name,
                'email' => $user->email,
            );
            JobSignUp::dispatch($mailArr);
            // Jobs End

            // Success Response Set
            $this->setMeta('status', config('appconstant.status_ok'));
            $this->setMeta('message', __('messages.register_success'));
            $this->setData('user', $user);
            return response()->json($this->setResponse(), config('appconstant.ok'));

        } catch (QueryException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.server_error'));
            return response()->json($this->setResponse(), config('appconstant.internal_server_error'));
        }
    }

    /**
     * @param SignInRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function signIn(SignInRequest $request)
    {
        try {

            // get User
            $user = $this->getUser(array(
                'email' => $request->email,
                'status' => config('appconstant.status_active'),
            ));

            // Email & password check
            if (!$user || !Hash::check($request->password, $user->password)) {
                $this->setMeta('status', config('appconstant.status_fail'));
                $this->setMeta('message', __('messages.invalid_email_password'));
                return response()->json($this->setResponse(), config('appconstant.unauthorized'));
            }

            // Jwt Token
            $token = null;
            if (!$token = auth()->guard('api')->attempt(request(['email', 'password']))) {
                return response()->json(['error' => 'Unauthorized'], 401);
            }

            $user->token = $token;
            // Success Response Set
            $this->setMeta('status', config('appconstant.status_ok'));
            $this->setMeta('message', __('messages.login_success'));
            $this->setData('user', $user);
            return response()->json($this->setResponse(), config('appconstant.ok'));

        } catch (QueryException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.server_error'));
            return response()->json($this->setResponse(), config('appconstant.internal_server_error'));
        }
    }

    /**
     * @param ForgotRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function forgotPassword(ForgotRequest $request)
    {
        try {
            // get User
            $user = $this->getUser(array(
                'email' => $request->email,
                'status' => config('appconstant.status_active'),
            ));

            // Check Email exits
            if ($user == null) {
                $this->setMeta('status', config('appconstant.status_fail'));
                $this->setMeta('message', __('messages.emailNotFound'));
                return response()->json($this->setResponse(), config('appconstant.not_found'));
            }

            $getToken = new GetTokens();
            $token = $getToken->limit(10);
            $token = $token->token;

            // Update Forgot Password Code Start
            $userArr = array(
                'forgot_password_code' => $token
            );
            $user->update($userArr);
            // Update Forgot Password Code End


            // Jobs Start
            $mailArr = array(
                'fullname' => $user->full_name,
                'email' => $user->email,
                'forgot_password_code' => $token
            );
            JobForgotPassword::dispatch($mailArr);
            // Jobs End

            // Success response set
            $this->setMeta('status', config('appconstant.status_ok'));
            $this->setMeta('message', __('messages.forgot_password_mail_success'));
            return response()->json($this->setResponse(), config('appconstant.ok'));

        } catch (QueryException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.server_error'));
            return response()->json($this->setResponse(), config('appconstant.internal_server_error'));
        }
    }

    /**
     * @param Request $request
     */
    public function resetPassword(ResetPassword $request)
    {
        try {
            // get User
            $user = $this->getUser(array(
                'email' => $request->email,
                'forgot_password_code' => $request->token,
                'status' => config('appconstant.status_active'),
            ));

            // Check Email exits
            if ($user == null) {
                $this->setMeta('status', config('appconstant.status_fail'));
                $this->setMeta('message', __('messages.emailNotFound'));
                return response()->json($this->setResponse(), config('appconstant.not_found'));
            }

            // User Create Start
            $userArr = array(
                'password' => Hash::make($request->password),
                'forgot_password_code' => null,
                'updated_at' => Carbon::now(),
            );
            $user->update($userArr);
            // User Create End

            // Success response set
            $this->setMeta('status', config('appconstant.status_ok'));
            $this->setMeta('message', __('messages.reset_password_success'));
            return response()->json($this->setResponse(), config('appconstant.ok'));

        } catch (QueryException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.server_error'));
            return response()->json($this->setResponse(), config('appconstant.internal_server_error'));
        }
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function signOut(Request $request)
    {
        auth()->guard(config('appconstant.api_auth_guard'))->logout(true);
        // Success response set
        $this->setMeta('status', config('appconstant.status_ok'));
        $this->setMeta('message', __('messages.signout_password_success'));
        return response()->json($this->setResponse(), config('appconstant.ok'));
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function forgotSetPassword(Request $request)
    {
        if (!$request->hasValidSignature() || (!$request->has('user') && !$request->has('token'))) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.expireUrl'));
            return response()->json($this->setResponse(), config('appconstant.token_invalid'));
        }

        // Check User
        $user = $this->getUser(array(
            'email' => $request->user,
            'forgot_password_code' => $request->token,
            'status' => config('appconstant.status_active')
        ));

        if (!$user) {

            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.expireUrl'));
            return response()->json($this->setResponse(), config('appconstant.token_invalid'));
        }
        $userArr = request(['user', 'token']);
        $this->setMeta('status', config('appconstant.status_ok'));
        $this->setMeta('message', __('messages.list_success'));
        $this->setData('user', $userArr);
        return response()->json($this->setResponse(), config('appconstant.ok'));
    }

    /**
     * @param $array
     * @return mixed
     */
    public function getUser($array){
        return User::where($array)->first();
    }
}
