<?php

namespace App\Http\Controllers\Api\V1\Category;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Category\CategoryStore;
use App\Models\Category;
use App\Traits\ApiResponse;
use Illuminate\Database\QueryException;
use Ramsey\Uuid\Uuid;
use App\Http\Requests\Api\V1\Category\Category as CategoryListRequest;

class CategoryController extends Controller
{
    use ApiResponse;

    /**
     * @param CategoryListRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(CategoryListRequest $request)
    {
        $user = $request->user;
        $category = Category::orderBy('id', 'desc');

        // Type Set
        $type = config('appconstant.income');
        if (request()->has('type')) {
            $type = request('type');
        }

        $category = $category->where(array(
            'user_id' => $user->id,
            'type' => $type,
            'status' => config('appconstant.status_active'),
        ));
        $category = $category->whereNull('parent_id');
        $category = $category->with(array('subCategory' => function($query){
            $query->where(
                'status', config('appconstant.status_active')
            );
        }));
        $category = $category->get();

        if ($category->isEmpty()) { // Category is empty
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.categoryNotFound'));
            return response()->json($this->setResponse(), config('appconstant.not_found'));
        }

        $this->setMeta('status', config('appconstant.status_ok'));
        $this->setMeta('message', __('messages.list_success'));
        $this->setData('category', $category);
        return response()->json($this->setResponse(), config('appconstant.ok'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryStore $request)
    {
        try {

            // UUID generate
            $uuid4 = Uuid::uuid4();
            $uuid = $uuid4->toString();

            $user = $request->user;

            // Category Array Store
            $categoryArr = array(
                'uuid' => $uuid,
                'parent_id' => null,
                'name' => $request->name,
                'type' => $request->type,
                'expense_type' => null,
                'status' => config('appconstant.status_active'),
            );

            // Sub category create
            if (request()->has('parent_id') && request('parent_id') != null) {

                $category = $user->category()
                    ->where(array(
                        'uuid' => request('parent_id'),
                        'type' => $request->type,
                        'expense_type' => $request->expense_type
                    ))->first();

                if ($category == null) {
                    $this->setMeta('status', config('appconstant.status_fail'));
                    $this->setMeta('message', __('messages.categoryNotFound'));
                    return response()->json($this->setResponse(), config('appconstant.not_found'));
                }

                $categoryArr['expense_type'] = $request->expense_type;
                $categoryArr['parent_id'] = $category->id;

            } else { // category create
                if ($request->type == config('appconstant.expense')) {
                    $categoryArr['expense_type'] = $request->expense_type;
                }
            }
            $category = $user->category()->save(new Category($categoryArr));

            $this->setMeta('status', config('appconstant.status_ok'));
            if (request()->has('parent_id') && request('parent_id') != null) {
                $this->setMeta('message', __('messages.sub_category_create_success'));
            } else {
                $this->setMeta('message', __('messages.category_create_success'));
            }
            $this->setData('category', $category);
            return response()->json($this->setResponse(), config('appconstant.created'));

        } catch (QueryException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.server_error'));
            return response()->json($this->setResponse(), config('appconstant.internal_server_error'));
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = request()->user;
        $category = Category::where(array(
            'uuid' => $id,
            'user_id' => $user->id
        ))->first();

        if ($category == null) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.categoryNotFound'));
            return response()->json($this->setResponse(), config('appconstant.not_found'));
        }

        // Success response set
        $this->setMeta('status', config('appconstant.status_ok'));
        $this->setMeta('message', __('messages.list_success'));
        $this->setData('category', $category);
        return response()->json($this->setResponse(), config('appconstant.ok'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {

            $user = request()->user;
            $category = $user->category()->where(array(
                'uuid' => $id
            ))->first();

            if ($category == null) {
                $this->setMeta('status', config('appconstant.status_fail'));
                $this->setMeta('message', __('messages.categoryNotFound'));
                return response()->json($this->setResponse(), config('appconstant.not_found'));
            }

            // Sub category Start
            if(request()->has('parent_id') && request('parent_id') != null){
                $alrAssCat = $category->subCategory()->count();
                if($alrAssCat > 0){
                    $this->setMeta('status', config('appconstant.status_fail'));
                    $this->setMeta('message', __('messages.alredyChiledCategoryAssign'));
                    return response()->json($this->setResponse(), config('appconstant.not_found'));
                }
                dd($user->category()->whereNull('parent_id'));
            }
            // Sub category End
            dd(request()->all());

            $category->name = $request->name;
            $category->save();

            // Success response set
            $this->setMeta('status', config('appconstant.status_ok'));
            $this->setMeta('message', __('messages.categoryUpdateSuccess'));
            $this->setData('category', $category);
            return response()->json($this->setResponse(), config('appconstant.ok'));

        } catch (QueryException $e) {
            $this->setMeta('status', config('appconstant.status_fail'));
            $this->setMeta('message', __('messages.server_error'));
            return response()->json($this->setResponse(), config('appconstant.internal_server_error'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
